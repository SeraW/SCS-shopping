STEPS TO SETUP AND RUN PROJECT:

1. Start up XAMPP Control Panel
2. Start Apache and MySQL
3. Select Explorer on the right section of the control panel
4. Select the htdocs folder
5. Drag the project folder from the submission .zip into the htdocs folder
6. Go to your browser and enter: http://localhost/phpmyadmin/index.php
7. On the left column, Select "New" to create a new database.
8. Enter Database Name as "project", then select Create.
9. Select the project database that you have just created and select "Import" on the top of the 
   page
10. Select "Choose File" 
11. Navigate to the project folder in the submission .zip or the htdocs folder
12. Go to the sql folder and select the add_tables.sql folder and import it. Then Select Go
13. Head to the link: http://localhost/project/home.php
DONE

ADMIN LOGIN:
Username: davetran
Password: coolguy

SEARCH FUNCTION:
To use the search mode on the homepage, you need to check the user table or order table 
for the user id or order id.
